# Dream Gate  
Dream Gate was originally conceived as a simple Valheim mod which would disabile the marking of bosses when a player clicks on a Vegvisir.  The idea was to encourage more exploration by forcing players to search for each boss.  However, since this mod was taking something away, it was only fair to give something else back, and the Dream Gate was born!  What is a Dream Gate?  It's simply a one way portal to a player's active bed which adheres to the same transport restrictions as any normal portal.  They can often come in handy when you find yourself far from home, but having forgotten to bring the parts to create a portal.
  
MUST be installed on both the client and the server!

## Configuration
  
On first launch a config will be generated in BepInEx/config, by default boss marking will be **disabled**, and teleporting will be **enabled**.
  
## License  
  
This project is licensed under the GNU General Public License v3.0 - see the [LICENSE](https://github.com/papajin68/valheim.dreamgate/blob/master/LICENSE) file for details  
